/* Generated for this PC by START.cmd. */
globalThis.LN_CONFIG = {base:'http://127.0.0.1:18765',token:''};
